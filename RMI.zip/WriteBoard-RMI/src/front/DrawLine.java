package front;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;

public class DrawLine extends JPanel {
	
    private MouseHandler mouseHandler = new MouseHandler();

    GeneralPath path = new GeneralPath();
    
    private boolean drawing = false;

    public DrawLine() {
        this.setPreferredSize(new Dimension(580, 580));
        this.addMouseListener(mouseHandler);
        this.addMouseMotionListener(mouseHandler);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.blue);
        g2d.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(8,
                BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL));
        if (path!=null) {
            g2d.draw(path);
        }
    }

    private class MouseHandler extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            Point p = e.getPoint(); 
            if (!drawing) {
                path.moveTo(p.x, p.y);
                drawing = true;
            } else {
                path.lineTo(p.x, p.y);
                drawing = false;
            }

            repaint();
        }
    }

    public void display(JFrame f) {
        f.setTitle("WriteBoard - Quadro");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton b = new JButton("Sair do Quadro");
        b.setPreferredSize(new Dimension(580, 100));
        this.add(b, BorderLayout.NORTH);
        b.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  f.getContentPane().removeAll();
        	  Telas.tela_inicial();
          }
        });
        
        this.setBackground(Color.white); 
        f.add(this);
        f.pack();
        f.setVisible(true);
    }

}