package front;
import front.Telas;

public class main {

	public static void main(String[] args) {
		Telas.init_tela();
		
	}

}
