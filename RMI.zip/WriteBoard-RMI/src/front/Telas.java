// java Program to create a simple JPanel add components to it 
package front;

import java.awt.event.*; 
import java.awt.*; 
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener; 
class Telas extends JFrame { 
	
	static JFrame f; 
	
	
	static public void lista_telas() {
		//create a panel 
        JPanel p =new JPanel(); 
         
        JList list; 
        
        DefaultListModel lista = new DefaultListModel();
        lista.addElement((String)"bala");
        lista.addElement((String)"doce");
        
        
        JButton b = new JButton("Sair da Listagem");
        b.setPreferredSize(new Dimension(580, 100));
        p.add(b, BorderLayout.NORTH);
        b.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  f.getContentPane().removeAll();
        	  Telas.tela_inicial();
          }
        });
        
        //create a new label 
        JLabel l= new JLabel("Selecione o quadro"); 
      //String array to store weekdays 
        String week[]= { "Quadro 1","Quadro 2","Quadro 3"}; 
        //create list 
        list= new JList(week); 
        list.setModel(lista);
     
        list.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent evt) {
              if (evt.getValueIsAdjusting())
                return;
              int index = list.getSelectedIndex();
              if (index != -1) {
            	    System.out.print(index + "\n");
            	}
             
            }
          });
        
        //add list to panel 
        p.add(l);
        p.add(list); 
        
        f.add(p); 
          
        f.setVisible(true);
	}
	
	
	static public void tela_inicial() {
		f.setTitle("WriteBoard");
		JButton b, b1;
		// create a panel to add buttons 
        JPanel p = new JPanel(new BorderLayout()); 
        
     // create a new buttons 
        b = new JButton("Criar Quadro"); 
        b.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  f.getContentPane().removeAll();
        	  DrawLine rc = new DrawLine();
              rc.display(f);
        	  
          }
        });
        
        b1 = new JButton("Listar Quadro"); 
        b1.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
        	  f.getContentPane().removeAll();
        	  Telas.lista_telas();
        	  
          }
        });
        
        b.setPreferredSize(new Dimension(600, 280));
        b1.setPreferredSize(new Dimension(600, 280));
  
        // add buttons and textfield to panel 
        p.add(b, BorderLayout.NORTH); 
        p.add(b1, BorderLayout.SOUTH);  
        
     // setbackground of panel 
        p.setBackground(Color.white); 
  
     // add panel to frame 
        f.add(p); 
  
        // set the size of frame 
        f.setSize(600, 600); 
        f.setVisible(true);
  
		
	}
	
	
    static public void init_tela() 
    { 
    	
        // create a new frame to stor text field and button 
        f = new JFrame("WriteBoard"); 
        
        Telas.tela_inicial();
        
        
    } 
    
} 